// Global state variables
let isAborted = false;
let isRunning = false;
let totalTasks = 0;
let completedTasks = 0;
let failedDownloads = [];

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.action === "toggleGUI") {
		createOrToggleGUI();
	}
});

// Initialize or toggle the floating GUI widget
function createOrToggleGUI() {
	let gui = document.getElementById("huji-downloader-widget");
	if (gui) {
		gui.style.display = gui.style.display === "none" ? "block" : "none";
		return;
	}

	gui = document.createElement("div");
	gui.id = "huji-downloader-widget";
	gui.dir = "ltr";

	Object.assign(gui.style, {
		position: "fixed",
		bottom: "40px",
		left: "40px",
		width: "360px",
		backgroundColor: "#ffffff",
		borderRadius: "16px",
		boxShadow:
			"0 10px 30px rgba(183, 28, 28, 0.15), 0 1px 3px rgba(0,0,0,0.05)",
		zIndex: "999999",
		padding: "24px",
		fontFamily: '"Segoe UI", Tahoma, sans-serif',
		border: "1px solid #ffebee",
	});

	gui.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid #ffebee; padding-bottom: 12px;">
            <h3 style="margin: 0; color: #b71c1c; font-size: 19px; font-weight: 700; display: flex; align-items: center; gap: 10px;">
                <img src="${chrome.runtime.getURL(
					"icon.png"
				)}" alt="Logo" style="width: 32px; height: 32px; border-radius: 6px; box-shadow: 0 2px 6px rgba(0,0,0,0.1);">
                HUJI Moodle
            </h3>
            <button id="huji-close-btn" style="background: #ffebee; border: none; border-radius: 50%; width: 30px; height: 30px; font-size: 14px; cursor: pointer; color: #c62828; display: flex; align-items: center; justify-content: center; transition: background 0.2s;">✖</button>
        </div>
        
        <div id="huji-main-view">
            <div style="display: flex; gap: 8px; margin-bottom: 12px;">
                <button id="huji-start-btn" style="flex: 1; background: linear-gradient(135deg, #e53935 0%, #b71c1c 100%); color: white; border: none; padding: 10px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 14px; box-shadow: 0 4px 10px rgba(183,28,28,0.2);">Download All</button>
                <button id="huji-select-btn" style="flex: 1; background: #1976d2; color: white; border: none; padding: 10px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 14px; box-shadow: 0 4px 10px rgba(25,118,210,0.2);">Custom Download</button>
            </div>
            <button id="huji-stop-btn" disabled style="width: 100%; background: #f5f5f5; color: #616161; border: 1px solid #e0e0e0; padding: 10px; border-radius: 8px; cursor: not-allowed; opacity: 0.5; font-weight: bold; font-size: 14px; margin-bottom: 20px;">Stop Process</button>
        </div>

        <div id="huji-selection-view" style="display: none; margin-bottom: 20px;">
            <div style="margin-bottom: 8px; font-weight: bold; font-size: 13px; color: #333;">Select items to download:</div>
            <div id="huji-recordings-list" style="max-height: 200px; overflow-y: auto; background: #f9f9f9; border: 1px solid #e0e0e0; border-radius: 8px; padding: 10px; margin-bottom: 12px; font-size: 13px; text-align: left;">
                <!-- List gets generated here -->
            </div>
            <div style="display: flex; gap: 8px;">
                <button id="huji-download-selected-btn" style="flex: 2; background: #43a047; color: white; border: none; padding: 10px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 14px; box-shadow: 0 4px 10px rgba(67,160,71,0.2);">Download Selected</button>
                <button id="huji-cancel-select-btn" style="flex: 1; background: #757575; color: white; border: none; padding: 10px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 14px;">Back</button>
            </div>
        </div>

        <div style="background: #ffebee; border-radius: 8px; height: 14px; overflow: hidden; margin-bottom: 12px; border: 1px solid #ffcdd2;">
            <div id="huji-progress-fill" style="background: linear-gradient(90deg, #ff5252, #c62828); height: 100%; width: 0%; transition: width 0.4s ease-out; border-radius: 8px;"></div>
        </div>
        <div id="huji-status-text" style="font-size: 13px; color: #b71c1c; text-align: center; font-weight: 500;">Waiting to start...</div>
    `;

	document.body.appendChild(gui);

	const closeBtn = document.getElementById("huji-close-btn");
	closeBtn.addEventListener(
		"mouseover",
		() => (closeBtn.style.background = "#ffcdd2")
	);
	closeBtn.addEventListener(
		"mouseout",
		() => (closeBtn.style.background = "#ffebee")
	);
	closeBtn.addEventListener("click", () => {
		gui.style.display = "none";
	});

	document.getElementById("huji-start-btn").addEventListener("click", () => {
		if (isRunning) return;
		startProcessUI();
		scrapeAndDownload(null);
	});

	document.getElementById("huji-select-btn").addEventListener("click", () => {
		if (isRunning) return;

		const panoptoNodes = document.querySelectorAll(
			'.block_panopto a[href*="Viewer.aspx"], .panopto-completed-container a'
		);
		const sectionNodes = document.querySelectorAll("h3.sectionname a");

		if (panoptoNodes.length === 0 && sectionNodes.length === 0) {
			alert("No downloadable content found on this page.");
			return;
		}

		const listContainer = document.getElementById("huji-recordings-list");
		listContainer.innerHTML = "";

		// --- Panopto Recordings Section ---
		if (panoptoNodes.length > 0) {
			const panoptoHeader = document.createElement("div");
			panoptoHeader.style.fontWeight = "bold";
			panoptoHeader.style.color = "#1976d2";
			panoptoHeader.style.marginBottom = "5px";
			panoptoHeader.innerText = "🎬 Panopto Recordings";
			listContainer.appendChild(panoptoHeader);

			const selectAllPanoptoLabel = document.createElement("label");
			selectAllPanoptoLabel.style.display = "block";
			selectAllPanoptoLabel.style.marginBottom = "10px";
			selectAllPanoptoLabel.style.fontWeight = "bold";
			selectAllPanoptoLabel.style.borderBottom = "1px solid #ddd";
			selectAllPanoptoLabel.style.paddingBottom = "5px";
			selectAllPanoptoLabel.style.cursor = "pointer";

			const selectAllPanoptoCb = document.createElement("input");
			selectAllPanoptoCb.type = "checkbox";
			selectAllPanoptoCb.addEventListener("change", (e) => {
				document
					.querySelectorAll(".huji-panopto-checkbox")
					.forEach((cb) => (cb.checked = e.target.checked));
			});
			selectAllPanoptoLabel.appendChild(selectAllPanoptoCb);
			selectAllPanoptoLabel.appendChild(
				document.createTextNode(" Select / Clear All Recordings")
			);
			listContainer.appendChild(selectAllPanoptoLabel);

			for (let i = 0; i < panoptoNodes.length; i++) {
				const a = panoptoNodes[i];
				let rawText =
					a.innerText ||
					a.textContent ||
					a.getAttribute("title") ||
					a.getAttribute("alt") ||
					"";
				let cleanTitle =
					rawText
						.replace(/[\r\n]+/g, " ")
						.trim()
						.replace(/[\/\\?%*:|"<>]/g, "-")
						.replace(/\.+$/, "")
						.trim() || "Recording";
				const recordingNumber = panoptoNodes.length - i;

				const label = document.createElement("label");
				label.style.display = "block";
				label.style.marginBottom = "6px";
				label.style.cursor = "pointer";

				const cb = document.createElement("input");
				cb.type = "checkbox";
				cb.value = i;
				cb.className = "huji-panopto-checkbox";

				label.appendChild(cb);
				label.appendChild(
					document.createTextNode(
						` (${recordingNumber}) ${cleanTitle}`
					)
				);
				listContainer.appendChild(label);
			}
		}

		// --- Course Sections Section ---
		if (sectionNodes.length > 0) {
			const sectionHeader = document.createElement("div");
			sectionHeader.style.fontWeight = "bold";
			sectionHeader.style.color = "#b71c1c";
			sectionHeader.style.marginTop = "15px";
			sectionHeader.style.marginBottom = "5px";
			sectionHeader.innerText = "📁 Course Sections (Units)";
			listContainer.appendChild(sectionHeader);

			const selectAllSectionsLabel = document.createElement("label");
			selectAllSectionsLabel.style.display = "block";
			selectAllSectionsLabel.style.marginBottom = "10px";
			selectAllSectionsLabel.style.fontWeight = "bold";
			selectAllSectionsLabel.style.borderBottom = "1px solid #ddd";
			selectAllSectionsLabel.style.paddingBottom = "5px";
			selectAllSectionsLabel.style.cursor = "pointer";

			const selectAllSectionsCb = document.createElement("input");
			selectAllSectionsCb.type = "checkbox";
			selectAllSectionsCb.addEventListener("change", (e) => {
				document
					.querySelectorAll(".huji-section-checkbox")
					.forEach((cb) => (cb.checked = e.target.checked));
			});
			selectAllSectionsLabel.appendChild(selectAllSectionsCb);
			selectAllSectionsLabel.appendChild(
				document.createTextNode(" Select / Clear All Sections")
			);
			listContainer.appendChild(selectAllSectionsLabel);

			for (let i = 0; i < sectionNodes.length; i++) {
				const node = sectionNodes[i];
				let cleanTitle =
					node.innerText
						.replace(/[\r\n]+/g, " ")
						.trim()
						.replace(/[\/\\?%*:|"<>]/g, "-")
						.replace(/\.+$/, "")
						.trim() || `Section_${i + 1}`;

				const label = document.createElement("label");
				label.style.display = "block";
				label.style.marginBottom = "6px";
				label.style.cursor = "pointer";

				const cb = document.createElement("input");
				cb.type = "checkbox";
				cb.value = i;
				cb.className = "huji-section-checkbox";

				label.appendChild(cb);
				label.appendChild(
					document.createTextNode(` (${i + 1}) ${cleanTitle}`)
				);
				listContainer.appendChild(label);
			}
		}

		document.getElementById("huji-main-view").style.display = "none";
		document.getElementById("huji-selection-view").style.display = "block";
	});

	document
		.getElementById("huji-cancel-select-btn")
		.addEventListener("click", () => {
			document.getElementById("huji-selection-view").style.display =
				"none";
			document.getElementById("huji-main-view").style.display = "block";
		});

	document
		.getElementById("huji-download-selected-btn")
		.addEventListener("click", () => {
			const panoptoCheckboxes = document.querySelectorAll(
				".huji-panopto-checkbox:checked"
			);
			const sectionCheckboxes = document.querySelectorAll(
				".huji-section-checkbox:checked"
			);

			if (
				panoptoCheckboxes.length === 0 &&
				sectionCheckboxes.length === 0
			) {
				alert("Please select at least one item to download.");
				return;
			}

			const panoptoNodes = document.querySelectorAll(
				'.block_panopto a[href*="Viewer.aspx"], .panopto-completed-container a'
			);
			const sectionNodes = document.querySelectorAll("h3.sectionname a");

			const selectedData = {
				panopto: [],
				sections: [],
			};

			panoptoCheckboxes.forEach((cb) => {
				const idx = parseInt(cb.value);
				selectedData.panopto.push({
					element: panoptoNodes[idx],
					index: idx,
					total: panoptoNodes.length,
				});
			});

			sectionCheckboxes.forEach((cb) => {
				const idx = parseInt(cb.value);
				selectedData.sections.push({
					title: sectionNodes[idx].innerText.trim(),
					url: sectionNodes[idx].href,
					originalIndex: idx, // Preserves the original chronological numbering
				});
			});

			document.getElementById("huji-selection-view").style.display =
				"none";
			document.getElementById("huji-main-view").style.display = "block";

			startProcessUI();
			scrapeAndDownload(selectedData);
		});

	document.getElementById("huji-stop-btn").addEventListener("click", () => {
		isAborted = true;
		document.getElementById("huji-status-text").innerText =
			"Stopping process...";
	});
}

function startProcessUI() {
	isAborted = false;
	isRunning = true;
	failedDownloads = []; // Reset failure log at the start of each run

	document.getElementById("huji-start-btn").disabled = true;
	document.getElementById("huji-start-btn").style.opacity = "0.7";
	document.getElementById("huji-start-btn").style.cursor = "wait";

	document.getElementById("huji-select-btn").disabled = true;
	document.getElementById("huji-select-btn").style.opacity = "0.7";
	document.getElementById("huji-select-btn").style.cursor = "wait";

	const stopBtn = document.getElementById("huji-stop-btn");
	stopBtn.disabled = false;
	stopBtn.style.opacity = "1";
	stopBtn.style.cursor = "pointer";
}

function updateProgress(text) {
	if (isAborted) return;
	completedTasks++;
	const percent =
		totalTasks === 0
			? 0
			: Math.min(Math.round((completedTasks / totalTasks) * 100), 100);
	document.getElementById("huji-progress-fill").style.width = percent + "%";
	document.getElementById(
		"huji-status-text"
	).innerText = `(${completedTasks}/${totalTasks}) ${text}`;
}

function finishProcess(msg) {
	isRunning = false;
	document.getElementById("huji-status-text").innerText = msg;

	document.getElementById("huji-start-btn").disabled = false;
	document.getElementById("huji-start-btn").style.opacity = "1";
	document.getElementById("huji-start-btn").style.cursor = "pointer";

	document.getElementById("huji-select-btn").disabled = false;
	document.getElementById("huji-select-btn").style.opacity = "1";
	document.getElementById("huji-select-btn").style.cursor = "pointer";

	const stopBtn = document.getElementById("huji-stop-btn");
	stopBtn.disabled = true;
	stopBtn.style.opacity = "0.5";
	stopBtn.style.cursor = "not-allowed";
}

// Fallback logic to extract clean video URLs from iframes
function cleanIframeUrl(url) {
	try {
		if (url.includes("youtube.com/embed/")) {
			const urlObj = new URL(url);
			const videoId = urlObj.pathname.split("/").pop();
			return `https://www.youtube.com/watch?v=${videoId}`;
		}
	} catch (e) {}
	return url;
}

// Helper function to sanitize strings for Windows Batch script execution
function sanitizeBat(str) {
	return str.replace(/[\r\n"]/g, "").replace(/%/g, "%%");
}

// Generate a robust FFmpeg command with PowerShell verification to prevent zero-byte files on Disk Full
function generateSafeFfmpegCommand(url, outputPath) {
	const safeUrl = sanitizeBat(url);
	const psPath = `\\"${outputPath}\\"`;

	let cmd = `ffmpeg -n -i "${safeUrl}" -c copy "${outputPath}"\r\n`;

	cmd += `powershell -Command "if (Test-Path ${psPath}) { if ((Get-Item ${psPath}).length -lt 100KB) { Remove-Item ${psPath} -Force; exit 1 } } else { exit 1 }"\r\n`;
	cmd += `if %errorlevel% neq 0 (\r\n`;
	cmd += `    echo.\r\n`;
	cmd += `    echo =======================================================\r\n`;
	cmd += `    echo ERROR: Download failed, corrupted, or DISK IS FULL!\r\n`;
	cmd += `    echo Stopping process to prevent empty files...\r\n`;
	cmd += `    echo =======================================================\r\n`;
	cmd += `    pause\r\n`;
	cmd += `    exit /b\r\n`;
	cmd += `)\r\n`;

	return cmd;
}

// Ensure proper tracking of failed downloads
async function handleDownload(urlToDownload, filename, originalUrl = "") {
	const res = await new Promise((resolve) => {
		chrome.runtime.sendMessage(
			{
				action: "downloadFile",
				url: urlToDownload,
				filename: filename,
			},
			(response) => resolve(response)
		);
	});

	if (!res || !res.success) {
		let logUrl = originalUrl || urlToDownload;
		if (logUrl.startsWith("data:")) logUrl = "Generated Text/HTML Document";

		failedDownloads.push({
			filename: filename,
			url: logUrl,
			error: res ? res.error : "Unknown Extension Error",
		});
	}
}

// Fetch with retry mechanism to prevent network drops during bulk operations
async function fetchWithRetry(url, retries = 3) {
	for (let i = 0; i < retries; i++) {
		try {
			const response = await fetch(url);
			if (!response.ok) throw new Error(`HTTP Error ${response.status}`);
			return await response.text();
		} catch (err) {
			if (i === retries - 1) throw err;
			await new Promise((r) => setTimeout(r, 1000));
		}
	}
}

// Main scraping and downloading logic
async function scrapeAndDownload(selectionData = null) {
	let courseName = document.querySelector("h1")
		? document
				.querySelector("h1")
				.innerText.trim()
				.replace(/[\/\\?%*:|"<>]/g, "-")
				.replace(/\.+$/, "")
				.trim()
		: "HUJI_Course";

	const courseFolderName = `Moodle_${courseName}_${Date.now()}`;

	let panoptoLinksToProcess = [];
	let sectionsToProcess = [];

	// Determine scanning path based on user selection (Download All vs. Custom Selection)
	if (selectionData !== null) {
		panoptoLinksToProcess = selectionData.panopto;
		sectionsToProcess = selectionData.sections;
	} else {
		const panoptoNodes = document.querySelectorAll(
			'.block_panopto a[href*="Viewer.aspx"], .panopto-completed-container a'
		);
		for (let i = 0; i < panoptoNodes.length; i++) {
			panoptoLinksToProcess.push({
				element: panoptoNodes[i],
				index: i,
				total: panoptoNodes.length,
			});
		}

		const sectionNodes = document.querySelectorAll("h3.sectionname a");
		for (let i = 0; i < sectionNodes.length; i++) {
			sectionsToProcess.push({
				title: sectionNodes[i].innerText.trim(),
				url: sectionNodes[i].href,
				originalIndex: i,
			});
		}
	}

	if (sectionsToProcess.length === 0 && panoptoLinksToProcess.length === 0) {
		finishProcess("No items found for download.");
		return;
	}

	totalTasks = sectionsToProcess.length * 4 + panoptoLinksToProcess.length;
	completedTasks = 0;
	updateProgress("Starting scan...");

	let batContent = "@echo off\r\nchcp 65001 >nul\r\n";
	batContent += "REM Check for FFmpeg installation\r\n";
	batContent += "ffmpeg -version >nul 2>&1\r\n";
	batContent += "if %errorlevel% neq 0 (\r\n";
	batContent +=
		"    echo =======================================================\r\n";
	batContent +=
		"    echo ERROR: FFmpeg is not installed or not in your PATH!\r\n";
	batContent +=
		"    echo Please download it from https://ffmpeg.org/download.html\r\n";
	batContent +=
		"    echo =======================================================\r\n";
	batContent += "    pause\r\n";
	batContent += "    exit /b\r\n";
	batContent += ")\r\n\r\n";

	let foundAnyPanoptoStream = false;

	// --- Step 1: Process Panopto Recordings ---
	if (panoptoLinksToProcess.length > 0) {
		for (let i = 0; i < panoptoLinksToProcess.length; i++) {
			if (isAborted) return finishProcess("Download stopped by user.");

			const item = panoptoLinksToProcess[i];
			const a = item.element;

			let rawText =
				a.innerText ||
				a.textContent ||
				a.getAttribute("title") ||
				a.getAttribute("alt") ||
				"";
			let cleanTitle = rawText
				.replace(/[\r\n]+/g, " ")
				.trim()
				.replace(/[\/\\?%*:|"<>]/g, "-")
				.replace(/\.+$/, "")
				.trim();

			if (!cleanTitle) cleanTitle = `Recording`;

			const recordingNumber = item.total - item.index;
			const recordingFolderName = `(${recordingNumber}) ${cleanTitle}`;
			const mainPanoptoFolder = "Panopto Recordings";

			try {
				const bgResponse = await new Promise((resolve) => {
					chrome.runtime.sendMessage(
						{ action: "fetchPanoptoStreams", url: a.href },
						(res) => resolve(res)
					);
				});

				if (
					bgResponse &&
					bgResponse.success &&
					bgResponse.streams &&
					bgResponse.streams.length > 0
				) {
					foundAnyPanoptoStream = true;

					const safeMainFolder = sanitizeBat(mainPanoptoFolder);
					const safeRecFolder = sanitizeBat(recordingFolderName);

					batContent += `REM ${safeRecFolder}\r\n`;
					batContent += `if not exist "%~dp0${safeMainFolder}\\${safeRecFolder}" mkdir "%~dp0${safeMainFolder}\\${safeRecFolder}"\r\n`;

					const uniqueStreams = [...new Set(bgResponse.streams)];

					uniqueStreams.forEach((m3u8Url, idx) => {
						const streamSuffix =
							idx === 0
								? "Camera"
								: idx === 1
								? "Screen"
								: `Stream_${idx + 1}`;
						const outputPath = `%~dp0${safeMainFolder}\\${safeRecFolder}\\${streamSuffix}.mp4`;

						batContent += generateSafeFfmpegCommand(
							m3u8Url,
							outputPath
						);
					});
				} else {
					const txtContent = `Recording Name: ${cleanTitle}\n\nDirect Panopto Link:\n${a.href}`;
					await handleDownload(
						`data:text/plain;charset=utf-8,${encodeURIComponent(
							txtContent
						)}`,
						`${courseFolderName}/${mainPanoptoFolder}/${recordingFolderName}/Link.txt`,
						a.href
					);
				}
			} catch (e) {
				const txtContent = `Recording Name: ${cleanTitle}\n\nDirect Panopto Link:\n${a.href}`;
				await handleDownload(
					`data:text/plain;charset=utf-8,${encodeURIComponent(
						txtContent
					)}`,
					`${courseFolderName}/${mainPanoptoFolder}/${recordingFolderName}/Link.txt`,
					a.href
				);
			}

			updateProgress(recordingFolderName);
			await new Promise((r) => setTimeout(r, 400));
		}
	}

	if (foundAnyPanoptoStream) {
		batContent +=
			"\r\necho.\r\necho All Panopto recordings have been successfully processed!\r\npause\r\n";
		await handleDownload(
			`data:application/x-bat;charset=utf-8,${encodeURIComponent(
				batContent
			)}`,
			`${courseFolderName}/Download_Panopto_Recordings.bat`
		);
	}

	// --- Step 2: Process Course Sections ---
	for (let sIndex = 0; sIndex < sectionsToProcess.length; sIndex++) {
		if (isAborted) return finishProcess("Download stopped by user.");

		const section = sectionsToProcess[sIndex];
		const safeSectionTitle = section.title
			.replace(/[\/\\?%*:|"<>]/g, "-")
			.replace(/\.+$/, "")
			.trim();
		// Preserve the original chronological numbering from the page:
		const sectionFolder = `(${
			section.originalIndex + 1
		}) ${safeSectionTitle}`;

		let sectionHtml;
		try {
			sectionHtml = await fetchWithRetry(section.url);
		} catch (error) {
			failedDownloads.push({
				filename: `Section: ${safeSectionTitle}`,
				url: section.url,
				error: `Failed to load section page after 3 retries: ${error.message}`,
			});
			continue;
		}

		const doc = new DOMParser().parseFromString(sectionHtml, "text/html");

		// Added modtype_lti to the query selector
		const linkElements = doc.querySelectorAll(
			".modtype_resource a, .modtype_url a, .modtype_videostream a, .modtype_folder a, .modtype_page a, .modtype_quiz a, .modtype_question a, .modtype_questionnaire a, .modtype_forum a, .modtype_lti a"
		);

		const validLinks = Array.from(linkElements).filter(
			(a) => !a.closest(".modtype_zoom") && !a.href.includes("mod/zoom/")
		);

		totalTasks += validLinks.length;

		for (let fIndex = 0; fIndex < validLinks.length; fIndex++) {
			if (isAborted) return finishProcess("Download stopped by user.");

			const a = validLinks[fIndex];
			let cloneA = a.cloneNode(true);
			cloneA
				.querySelectorAll(".accesshide")
				.forEach((node) => node.remove());

			let rawTitle =
				cloneA.getAttribute("title") ||
				cloneA.innerText ||
				cloneA.textContent ||
				"";
			let cleanTitle = rawTitle
				.replace(/[\r\n]+/g, " ")
				.trim()
				.replace(/[\/\\?%*:|"<>]/g, "-")
				.replace(/\.+$/, "")
				.trim();

			if (!cleanTitle) cleanTitle = `File_${fIndex + 1}`;

			const baseName = `(${fIndex + 1}) ${cleanTitle}`;

			const isFolder = !!a.closest(".modtype_folder");
			const isPage = !!a.closest(".modtype_page");
			const isQuiz = !!a.closest(".modtype_quiz");
			const isQuestion = !!a.closest(".modtype_question");
			const isQuestionnaire = !!a.closest(".modtype_questionnaire");
			const isForum = !!a.closest(".modtype_forum");
			const isLti = !!a.closest(".modtype_lti");
			const isUrl = !!a.closest(".modtype_url");
			const isResource = a.href.includes("mod/resource/view.php");

			if (isLti) {
				// Handling External Tools (LTI)
				// Create a text file containing the URL to access it directly via Moodle.
				const ltiLink =
					a.href && a.href.includes("mod/lti/launch.php")
						? a.href
						: a.href.replace(
								"mod/lti/view.php",
								"mod/lti/launch.php"
						  );
				const txtContent = `External Learning Tool: ${cleanTitle}\n\nPlease access this resource directly via Moodle:\n${ltiLink}\n\n(This is a secure external tool link and cannot be downloaded directly.)`;
				const downloadUrl = `data:text/plain;charset=utf-8,${encodeURIComponent(
					txtContent
				)}`;
				const finalFilename = `${courseFolderName}/${sectionFolder}/${baseName}.txt`;
				await handleDownload(downloadUrl, finalFilename, a.href);
			} else if (isFolder) {
				try {
					const folderHtml = await fetchWithRetry(a.href);
					const folderDoc = new DOMParser().parseFromString(
						folderHtml,
						"text/html"
					);

					// HUJI specific download folder button (ZIP)
					const downloadForm = folderDoc.querySelector(
						'form[action*="download_folder.php"]'
					);
					if (downloadForm) {
						const action = downloadForm.getAttribute("action");
						const idInput =
							downloadForm.querySelector('input[name="id"]');
						if (idInput) {
							const zipUrl = `${action}?id=${idInput.value}`;
							const finalFilename = `${courseFolderName}/${sectionFolder}/${baseName}.zip`;
							await handleDownload(zipUrl, finalFilename, a.href);
						}
					} else {
						// Original Bar-Ilan logic as a safe fallback
						const folderFiles =
							folderDoc.querySelectorAll(".fp-filename a");
						for (let i = 0; i < folderFiles.length; i++) {
							if (isAborted) break;
							const fileLink = folderFiles[i];
							const fileName = fileLink.innerText
								.trim()
								.replace(/[\/\\?%*:|"<>]/g, "-")
								.replace(/\.+$/, "")
								.trim();

							const finalFilename = `${courseFolderName}/${sectionFolder}/${baseName}/${fileName}`;
							await handleDownload(
								fileLink.href +
									(fileLink.href.includes("?") ? "&" : "?") +
									"forcedownload=1",
								finalFilename,
								fileLink.href
							);
							await new Promise((r) => setTimeout(r, 600));
						}
					}
				} catch (err) {
					failedDownloads.push({
						filename: `Folder contents: ${baseName}`,
						url: a.href,
						error: `Failed to parse folder after retries: ${err.message}`,
					});
				}
			} else if (
				isPage ||
				isQuiz ||
				isQuestion ||
				isQuestionnaire ||
				isForum
			) {
				try {
					const pageHtml = await fetchWithRetry(a.href);
					const pageDoc = new DOMParser().parseFromString(
						pageHtml,
						"text/html"
					);

					let downloadUrl = null;
					let ext = "";
					let handledSpecial = false;

					const iframeNode = pageDoc.querySelector("iframe");
					if (iframeNode && iframeNode.src) {
						const cleanSrc = cleanIframeUrl(iframeNode.src);
						const txtContent = `Resource Name: ${cleanTitle}\n\nExtracted Source Link:\n${cleanSrc}`;
						downloadUrl = `data:text/plain;charset=utf-8,${encodeURIComponent(
							txtContent
						)}`;
						ext = ".txt";
						handledSpecial = true;
					}

					if (
						!handledSpecial &&
						(isPage || isQuestionnaire || isForum)
					) {
						let fileUrl = null;
						const videoNode = pageDoc.querySelector(
							"video source, video"
						);
						if (videoNode)
							fileUrl = videoNode.src || videoNode.currentSrc;

						if (!fileUrl) {
							const mp4Match = pageHtml.match(
								/(https:\/\/[^\s"'<>]+\.mp4)/
							);
							if (mp4Match) fileUrl = mp4Match[1];
						}

						if (fileUrl) {
							ext = ".mp4";
							downloadUrl =
								fileUrl +
								(fileUrl.includes("?") ? "&" : "?") +
								"forcedownload=1";
							handledSpecial = true;
						}
					}

					if (!handledSpecial) {
						const mainContent =
							pageDoc.querySelector('[role="main"]') ||
							pageDoc.querySelector("#region-main") ||
							pageDoc.body;
						const cleanHtml = `
                            <!DOCTYPE html>
                            <html dir="ltr">
                            <head>
                                <meta charset="utf-8">
                                <title>${cleanTitle}</title>
                                <style>
                                    body { font-family: 'Segoe UI', Tahoma, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; line-height: 1.6; color: #333; direction: ltr; }
                                    img { max-width: 100%; height: auto; border-radius: 8px; margin-top: 10px; }
                                    a { color: #b71c1c; text-decoration: none; }
                                    .activity-header { display: none; }
                                </style>
                            </head>
                            <body>
                                <h1 style="color: #b71c1c; border-bottom: 2px solid #ffebee; padding-bottom: 10px;">${cleanTitle}</h1>
                                ${
									mainContent
										? mainContent.innerHTML
										: "<p>No content found on this page.</p>"
								}
                            </body>
                            </html>
                        `;
						downloadUrl = `data:text/html;charset=utf-8,${encodeURIComponent(
							cleanHtml
						)}`;
						ext = ".html";
					}

					const finalFilename = `${courseFolderName}/${sectionFolder}/${baseName}${ext}`;
					await handleDownload(downloadUrl, finalFilename, a.href);
				} catch (e) {
					failedDownloads.push({
						filename: `Page/Forum content: ${baseName}`,
						url: a.href,
						error: `Failed to fetch page after retries: ${e.message}`,
					});
				}
			} else if (isUrl) {
				// Handling modtype_url components
				// NEW LOGIC: Use the background script to resolve cross-origin HTTP 302 redirects natively
				let finalLinkToSave = a.href;

				try {
					const bgResponse = await new Promise((resolve) => {
						chrome.runtime.sendMessage(
							{ action: "resolveRedirect", url: a.href },
							resolve
						);
					});

					if (bgResponse && bgResponse.success) {
						finalLinkToSave = bgResponse.finalUrl;

						// If it still points to Moodle, it means Moodle served an HTML page instead of a redirect.
						// We fallback to parsing the HTML to extract the embedded link.
						if (finalLinkToSave.includes("mod/url/view.php")) {
							const html = await fetchWithRetry(a.href);
							const innerDoc = new DOMParser().parseFromString(
								html,
								"text/html"
							);

							let extractedLink = null;

							// 1. Check for iframe (Solves embedded Google Forms and Google Maps issues!)
							const iframeNode = innerDoc.querySelector("iframe");
							if (iframeNode && iframeNode.src) {
								extractedLink = iframeNode.src;
							}

							// 2. Check for explicit Moodle workaround link
							if (!extractedLink) {
								const urlLink = innerDoc.querySelector(
									".urlworkaround a, .resourceworkaround a"
								);
								if (urlLink && urlLink.href)
									extractedLink = urlLink.href;
							}

							// 3. Check for onclick javascript redirects
							if (!extractedLink) {
								const onclickLinks =
									innerDoc.querySelectorAll("[onclick]");
								for (let l of onclickLinks) {
									const onclickValue =
										l.getAttribute("onclick");
									if (
										onclickValue &&
										onclickValue.includes("location.href")
									) {
										const match = onclickValue.match(
											/location\.href\s*=\s*['"]([^'"]+)['"]/
										);
										if (match && match[1]) {
											extractedLink = match[1];
											break;
										}
									}
								}
							}

							// 4. Check for any external link in the main content
							if (!extractedLink) {
								const externalLinks =
									innerDoc.querySelectorAll(
										'div[role="main"] a'
									);
								for (let l of externalLinks) {
									if (
										l.href &&
										!l.href.includes("mod/url/view.php") &&
										l.href.startsWith("http")
									) {
										extractedLink = l.href;
										break;
									}
								}
							}

							if (extractedLink) {
								finalLinkToSave = extractedLink;
							}
						}

						const cleanExtracted = cleanIframeUrl(finalLinkToSave);

						// Check if it's a Panopto URL masquerading as a modtype_url
						if (
							cleanExtracted.includes("panopto") ||
							cleanExtracted.includes("Viewer.aspx")
						) {
							try {
								const panoptoBg = await new Promise(
									(resolve) => {
										chrome.runtime.sendMessage(
											{
												action: "fetchPanoptoStreams",
												url: cleanExtracted,
											},
											(res) => resolve(res)
										);
									}
								);

								if (
									panoptoBg &&
									panoptoBg.success &&
									panoptoBg.streams &&
									panoptoBg.streams.length > 0
								) {
									let batContent =
										"@echo off\r\nchcp 65001 >nul\r\n";
									const safeRecFolder =
										sanitizeBat(cleanTitle);
									batContent += `REM ${safeRecFolder}\r\n`;
									batContent += `if not exist "%~dp0${safeRecFolder}" mkdir "%~dp0${safeRecFolder}"\r\n`;

									const uniqueStreams = [
										...new Set(panoptoBg.streams),
									];
									uniqueStreams.forEach((m3u8Url, idx) => {
										const streamSuffix =
											idx === 0
												? "Camera"
												: idx === 1
												? "Screen"
												: `Stream_${idx + 1}`;
										const outputPath = `%~dp0${safeRecFolder}\\${streamSuffix}.mp4`;
										batContent += generateSafeFfmpegCommand(
											m3u8Url,
											outputPath
										);
									});

									const downloadUrl = `data:application/x-bat;charset=utf-8,${encodeURIComponent(
										batContent
									)}`;
									const finalFilename = `${courseFolderName}/${sectionFolder}/${baseName}.bat`;
									await handleDownload(
										downloadUrl,
										finalFilename,
										a.href
									);
								} else {
									throw new Error("No Panopto streams found");
								}
							} catch (panoptoErr) {
								// Fallback to text if Panopto extraction fails
								const txtContent = `Resource Name: ${cleanTitle}\n\nSource URL:\n${cleanExtracted}`;
								const downloadUrl = `data:text/plain;charset=utf-8,${encodeURIComponent(
									txtContent
								)}`;
								const finalFilename = `${courseFolderName}/${sectionFolder}/${baseName}.txt`;
								await handleDownload(
									downloadUrl,
									finalFilename,
									a.href
								);
							}
						} else {
							// Standard Text file for general URL
							const txtContent = `Resource Name: ${cleanTitle}\n\nSource URL:\n${cleanExtracted}`;
							const downloadUrl = `data:text/plain;charset=utf-8,${encodeURIComponent(
								txtContent
							)}`;
							const finalFilename = `${courseFolderName}/${sectionFolder}/${baseName}.txt`;
							await handleDownload(
								downloadUrl,
								finalFilename,
								a.href
							);
						}
					} else {
						throw new Error("Background resolution failed");
					}
				} catch (e) {
					// Complete Fallback
					const txtContent = `Resource Name: ${cleanTitle}\n\nURL:\n${a.href}`;
					const downloadUrl = `data:text/plain;charset=utf-8,${encodeURIComponent(
						txtContent
					)}`;
					const finalFilename = `${courseFolderName}/${sectionFolder}/${baseName}.txt`;
					await handleDownload(downloadUrl, finalFilename, a.href);
				}
			} else {
				// Handling standard resources (PDFs, PPTs, etc.)
				let fetchUrl = a.href;

				if (isResource) {
					fetchUrl +=
						(fetchUrl.includes("?") ? "&" : "?") + "redirect=1";
				}

				let downloadUrl = fetchUrl;
				let ext = "";
				let contentType = "";
				let finalUrl = fetchUrl;

				try {
					const controller = new AbortController();
					const res = await fetch(fetchUrl, {
						signal: controller.signal,
					});
					contentType = res.headers.get("content-type") || "";
					finalUrl = res.url;
					ext = getExtension(finalUrl, contentType);
					controller.abort();
				} catch (err) {}

				if (contentType.includes("text/html") && !ext) {
					try {
						const html = await fetchWithRetry(fetchUrl);
						const innerDoc = new DOMParser().parseFromString(
							html,
							"text/html"
						);

						const iframeNode = innerDoc.querySelector("iframe");
						if (iframeNode && iframeNode.src) {
							const cleanSrc = cleanIframeUrl(iframeNode.src);
							const txtContent = `Resource Name: ${cleanTitle}\n\nExtracted Source Link:\n${cleanSrc}`;
							downloadUrl = `data:text/plain;charset=utf-8,${encodeURIComponent(
								txtContent
							)}`;
							ext = ".txt";
						} else {
							let fileUrl = null;
							const videoNode = innerDoc.querySelector(
								"video source, video"
							);
							if (videoNode)
								fileUrl = videoNode.src || videoNode.currentSrc;

							if (!fileUrl) {
								const mp4Match = html.match(
									/(https:\/\/[^\s"'<>]+\.mp4)/
								);
								if (mp4Match) fileUrl = mp4Match[1];
							}

							if (fileUrl) {
								ext = ".mp4";
								downloadUrl =
									fileUrl +
									(fileUrl.includes("?") ? "&" : "?") +
									"forcedownload=1";
							}
						}
					} catch (e) {
						failedDownloads.push({
							filename: `HTML Resource: ${baseName}`,
							url: fetchUrl,
							error: `Failed to extract HTML resource after retries: ${e.message}`,
						});
					}
				} else {
					downloadUrl = finalUrl;
					if (
						!downloadUrl.includes("forcedownload=1") &&
						!downloadUrl.startsWith("data:")
					) {
						downloadUrl +=
							(downloadUrl.includes("?") ? "&" : "?") +
							"forcedownload=1";
					}
				}

				if (!ext && a.closest(".modtype_videostream")) ext = ".mp4";
				if (!ext && isResource) ext = ".pdf";

				if (!ext) {
					const txtContent = `Resource Name: ${cleanTitle}\n\nURL:\n${a.href}`;
					downloadUrl = `data:text/plain;charset=utf-8,${encodeURIComponent(
						txtContent
					)}`;
					ext = ".txt";
				}

				const finalFilename = `${courseFolderName}/${sectionFolder}/${baseName}${ext}`;
				await handleDownload(downloadUrl, finalFilename, a.href);
			}
			updateProgress(baseName);
			await new Promise((r) => setTimeout(r, 600));
		}
	}

	// Finalize process and generate error logs if necessary
	if (!isAborted) {
		completedTasks = totalTasks;
		document.getElementById("huji-progress-fill").style.width = "100%";

		if (failedDownloads.length > 0) {
			let logContent =
				"HUJI Moodle Downloader - Failed Downloads Log\r\n";
			logContent += `Date: ${new Date().toLocaleString()}\r\n`;
			logContent +=
				"=================================================\r\n\r\n";

			failedDownloads.forEach((fail) => {
				logContent += `File: ${fail.filename}\r\n`;
				logContent += `URL:  ${fail.url}\r\n`;
				logContent += `Error: ${fail.error}\r\n`;
				logContent +=
					"-------------------------------------------------\r\n";
			});

			await handleDownload(
				`data:text/plain;charset=utf-8,${encodeURIComponent(
					logContent
				)}`,
				`${courseFolderName}/Failed_Downloads_Log.txt`
			);

			finishProcess(
				`Completed with ${failedDownloads.length} errors. Check the Log file.`
			);
		} else {
			finishProcess("Download completed successfully!");
		}
	}
}

// Helper function to determine file extension based on URL and Content-Type
function getExtension(url, contentType) {
	url = (url || "").toLowerCase();
	contentType = (contentType || "").toLowerCase();

	if (contentType.includes("pdf")) return ".pdf";
	if (contentType.includes("mp4") || contentType.includes("video"))
		return ".mp4";
	if (
		contentType.includes("word") ||
		contentType.includes("document") ||
		contentType.includes("wordprocessingml")
	)
		return ".docx";
	if (
		contentType.includes("powerpoint") ||
		contentType.includes("presentation") ||
		contentType.includes("presentationml")
	)
		return ".pptx";
	if (
		contentType.includes("excel") ||
		contentType.includes("sheet") ||
		contentType.includes("spreadsheetml")
	)
		return ".xlsx";
	if (contentType.includes("zip")) return ".zip";
	if (contentType.includes("text/plain")) return ".txt";

	const match = url.match(/\.([a-z0-9]+)(?:\?|#|$)/i);
	if (match && match[1] !== "php") return `.${match[1]}`;
	return "";
}
