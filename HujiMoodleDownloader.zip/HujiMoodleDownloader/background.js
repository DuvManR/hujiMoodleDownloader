chrome.action.onClicked.addListener((tab) => {
	chrome.tabs.sendMessage(tab.id, { action: "toggleGUI" }).catch(() => {
		console.log("The script is not yet loaded on this page.");
	});
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.action === "downloadFile") {
		// Trigger the safe download mechanism with 3 retries to prevent network errors
		downloadWithRetry(request.url, request.filename, 3).then((result) =>
			sendResponse(result)
		);
		return true; // Keep the message channel open for asynchronous response
	} else if (request.action === "resolveRedirect") {
		// New: Follow external redirects (e.g., Google Maps/Forms) bypassing CORS
		fetch(request.url)
			.then((res) => sendResponse({ success: true, finalUrl: res.url }))
			.catch((err) =>
				sendResponse({ success: false, error: err.toString() })
			);
		return true;
	} else if (request.action === "fetchPanoptoStreams") {
		const urlObj = new URL(request.url);
		const videoId = urlObj.searchParams.get("id");
		const host = urlObj.hostname;

		// Fetch streaming data directly from Panopto API
		fetch(`https://${host}/Panopto/Pages/Viewer/DeliveryInfo.aspx`, {
			method: "POST",
			headers: { "Content-Type": "application/x-www-form-urlencoded" },
			body: `deliveryId=${videoId}&responseType=json`,
			credentials: "include",
		})
			.then((res) => res.text())
			.then((text) => {
				let streams = [];
				try {
					const data = JSON.parse(text);
					if (data.Delivery && data.Delivery.Streams) {
						streams = data.Delivery.Streams.map(
							(s) => s.StreamUrl
						).filter((url) => url && url.includes(".m3u8"));
					}
				} catch (e) {}

				// Fallback mechanism in case JSON parsing fails
				if (streams.length === 0) {
					const matches = text.match(
						/https:\/\/[^"'\s<>]*master\.m3u8[^"'\s<>]*/gi
					);
					if (matches) {
						streams = [...new Set(matches)];
					}
				}

				sendResponse({ success: true, streams: streams });
			})
			.catch((err) =>
				sendResponse({ success: false, error: err.toString() })
			);

		return true; // Keep the message channel open for asynchronous response
	}
});

// Background retry function for failed downloads
async function downloadWithRetry(url, filename, retries) {
	for (let i = 0; i < retries; i++) {
		try {
			await startAndWaitForDownload(url, filename);
			return { success: true };
		} catch (error) {
			console.log(
				`Download failed for ${filename}, attempt ${
					i + 1
				} of ${retries}. Error: ${error.message}`
			);
			if (i === retries - 1) {
				return { success: false, error: error.message }; // Finally fail after max attempts
			}
			await new Promise((res) => setTimeout(res, 1500)); // Wait 1.5 seconds before retrying
		}
	}
}

// Function that halts execution until the specific file is successfully downloaded
function startAndWaitForDownload(url, filename) {
	return new Promise((resolve, reject) => {
		chrome.downloads.download(
			{
				url: url,
				filename: filename,
				conflictAction: "overwrite",
			},
			(downloadId) => {
				if (chrome.runtime.lastError) {
					return reject(new Error(chrome.runtime.lastError.message));
				}

				// Failsafe mechanism: if a file is stuck for more than 2 minutes, abort to prevent script freezing
				let timeoutId = setTimeout(() => {
					chrome.downloads.onChanged.removeListener(listener);
					chrome.downloads.cancel(downloadId);
					reject(new Error("Download timed out after 2 minutes"));
				}, 120000);

				function listener(delta) {
					if (delta.id === downloadId && delta.state) {
						if (delta.state.current === "complete") {
							clearTimeout(timeoutId);
							chrome.downloads.onChanged.removeListener(listener);
							resolve();
						} else if (delta.state.current === "interrupted") {
							clearTimeout(timeoutId);
							chrome.downloads.onChanged.removeListener(listener);
							reject(
								new Error(
									delta.error?.current ||
										"Interrupted by network/user"
								)
							);
						}
					}
				}
				chrome.downloads.onChanged.addListener(listener);
			}
		);
	});
}
